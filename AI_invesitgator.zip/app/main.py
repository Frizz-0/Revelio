"""Application entry point."""


if __name__ == "__main__":
    print("AI Investigator")
